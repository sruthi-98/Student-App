package com.example.user.student_app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView list;
    Button btn;
    SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        updatelist();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent activity2 = new Intent(MainActivity.this, add_student.class);
                startActivity(activity2);

            }
        });

    }


    public void updatelist() {
        btn = (Button) findViewById(R.id.add);
        list = (ListView) findViewById(R.id.list);

        final ArrayList<String> al = new ArrayList<>();
        ArrayAdapter adapter;

        database = openOrCreateDatabase("myDatabase", MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS tablename (" +
                "name TEXT NOT NULL," +
                "branch TEXT NOT NULL," +
                "gender TEXT ," +
                "interests TEXT );");

        Cursor resultSet = database.rawQuery("SELECT name, branch FROM tablename ",
                null);
        resultSet.moveToFirst();
        while (!resultSet.isAfterLast()) {
            al.add(resultSet.getString(0) + "\n" + resultSet.getString(1));
            resultSet.moveToNext();
        }
        adapter = new ArrayAdapter(this, R.layout.listview, al);
        list.setAdapter(adapter);
        resultSet.close();
        list.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> arg0, View view,
                                            int position, long id) {
                        Bundle bundle = new Bundle();
                        String[] parts = al.get(position).split("\n");
                        bundle.putString("name", parts[0]);
                        bundle.putString("branch", parts[1]);
                        Intent activity3 = new Intent(MainActivity.this, display.class);
                        activity3.putExtras(bundle);
                        startActivity(activity3);
                    }
                });
    }

    @Override
    public void onResume() {
        updatelist();
        super.onResume();

    }

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.credits:
                Toast.makeText(MainActivity.this, "" + "Sruthi Suresh", Toast.LENGTH_LONG).show();
                return true;
            case R.id.site:
                Intent o_site = new Intent(MainActivity.this, official.class );
                startActivity(o_site);
                //return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    boolean back  = false;
    @Override
    public void onBackPressed() {

        if (back) {
            super.onBackPressed();
        } else {
            Snackbar.make(btn, "Tap again to exit", Snackbar.LENGTH_SHORT).show();
            back = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    back = false;
                }
            }, 2000);
        } ;
    }
}

