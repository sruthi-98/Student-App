package com.example.user.student_app;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.user.student_app.R;

import java.util.ArrayList;

public class display extends AppCompatActivity {
    TextView tname, tbranch, tgender, tinterest;
    ArrayList<String> al = new ArrayList<>();
    ArrayAdapter adapter;
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        tname = (TextView) findViewById(R.id.name2);
        tbranch = (TextView) findViewById(R.id.branch2);
        tgender = (TextView) findViewById(R.id.gender2);
        tinterest = (TextView) findViewById(R.id.interest2);


        Bundle bundle = getIntent().getExtras();
        String name = bundle.getString("name");
        String branch = bundle.getString("branch");



        SQLiteDatabase database = openOrCreateDatabase("myDatabase", MODE_PRIVATE, null);


        Cursor resultSet = database.rawQuery("SELECT * FROM tablename WHERE name = ? AND branch = ?",
                new String[]{name,branch});
        resultSet.moveToFirst();
        tname.setText(resultSet.getString(0));
        tbranch.setText(resultSet.getString(1));
        tgender.setText(resultSet.getString(2));
        tinterest.setText(resultSet.getString(3));
        resultSet.close();


    }
}


