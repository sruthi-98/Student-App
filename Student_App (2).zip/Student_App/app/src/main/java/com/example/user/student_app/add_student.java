package com.example.user.student_app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import static android.R.attr.label;

public class add_student extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Button submit;
    RadioButton male, female;
    RadioGroup gender;
    CheckBox web, design, and;
    EditText name;
    Spinner branch;
    String branchNames[] = {
            "Chemical Engineering",
            "Civil Engineering",
            "Computer Science and Engineering",
            "Electrical and Electronics Engineering",
            "Electronics and Communication Engineering",
            "Mechanical Engineering",
            "Production Engineering"
      };
    SQLiteDatabase database;
    int count = 0;
    final String PREFS_NAME = "register_count";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        submit = (Button)findViewById(R.id.btn);
        name = (EditText)findViewById(R.id.name);
        gender = (RadioGroup)findViewById(R.id.gender);
        male = (RadioButton)findViewById(R.id.rbm);
        female = (RadioButton)findViewById(R.id.rbf);


        web = (CheckBox)findViewById(R.id.cbw);
        design = (CheckBox)findViewById(R.id.cbd);
        and = (CheckBox)findViewById(R.id.cba);

        branch = (Spinner) findViewById(R.id.list);

        branch.setOnItemSelectedListener(this);
        ArrayAdapter<String> aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,branchNames);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        branch.setAdapter(aa);

        database = openOrCreateDatabase("myDatabase", MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS tablename (" +
                "name TEXT NOT NULL ," +
                "branch TEXT NOT NULL ," +
                "gender TEXT ," +
                "interests TEXT );");

        submit.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                String n = name.getText().toString();
                String b = branch.getSelectedItem().toString();

                Cursor resultSet = database.rawQuery("SELECT * FROM tablename WHERE name = ? AND branch = ?",
                        new String[]{n, b});
                resultSet.moveToFirst();
                if (!resultSet.isAfterLast()) {
                    Toast.makeText(add_student.this, "Duplicate values, Values not stored", Toast.LENGTH_LONG).show();
                    resultSet.close();
                    return;
                }
                resultSet.close();

                if (n.trim().length() == 0) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(add_student.this);
                    builder.setTitle("ALERT MESSAGE");
                    builder.setMessage("Name is Mandatory field");
                    builder.setCancelable(true);
                    builder.show();


                } else {
                    SharedPreferences sharedpreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    count = sharedpreferences.getInt(PREFS_NAME,0);
                    count++;
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putInt(PREFS_NAME, count);
                    editor.commit();

                    Snackbar.make(gender,"Student "+Integer.toString(count)+" added",
                            Snackbar.LENGTH_SHORT).show();

                    int id = gender.getCheckedRadioButtonId();
                    RadioButton g = (RadioButton) findViewById(id);
                    String gen = g.getText().toString();

                    String intrst = "";
                    if (web.isChecked()) {
                        intrst = intrst + "Web,";

                    }
                    if (and.isChecked()) {
                        intrst = intrst + " Android,";
                    }

                    if (design.isChecked()) {
                        intrst = intrst + " Design";
                    }


                    database.execSQL("INSERT INTO tablename VALUES(" +
                            "'" + n + "', '" + b + "','" + gen + "', '" + intrst + "');");



                }
            }
        });
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}
