package com.example.user.student_app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class official extends AppCompatActivity {
    WebView w1;
    Button btn, back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_official);

        btn=(Button)findViewById(R.id.ref);
        back=(Button)findViewById(R.id.back);

        w1=(WebView)findViewById(R.id.w1);
        w1.setWebViewClient(new WebViewClient());
        w1.loadUrl("http://www.google.com");

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                w1.reload();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                w1.goBack();
            }
        });
    }
}

